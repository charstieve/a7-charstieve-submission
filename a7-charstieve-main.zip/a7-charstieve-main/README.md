# Assignment 7: xv6 Hacking

This is the starter code for [Assignment 7]. It contains the full sources of xv6 with minor modifications, as well as some initial test programs to exercise the new system call.

You can also browse the xv6 source code [here](https://khoury-cs3650.github.io/l/10/xv6-global/).

[Assignment 7]:https://khoury-cs3650.github.io/a7.html

